//
//  TrackViewController.swift
//  Showcase
//
//  Created by Tony Stark on 2/1/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit


class TrackViewController: UIViewController, CLLocationManagerDelegate {
    var locationManager: CLLocationManager!
    @IBOutlet weak var locationText: UITextView!
    @IBOutlet weak var toggleSwitch: UISwitch!
    @IBOutlet var mapDisplay: MKMapView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        locationText.layer.cornerRadius = 5.0
        mapDisplay.layer.cornerRadius = 5.0
        
//                let location = CLLocationCoordinate2D(
//                    latitude: 51.50007773,
//                    longitude: -0.1246402)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations:[CLLocation]) {
        let place:CLLocation = locations[locations.endIndex-1] as CLLocation
        self.locationText.text = place.description
        
        let location = place.coordinate
        
        let span = MKCoordinateSpanMake(0.05, 0.05)
        let region = MKCoordinateRegion(center: location, span: span)
        mapDisplay.setRegion(region, animated: true)
        
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = "HSE Building"
        annotation.subtitle = "This your current location"
        mapDisplay.addAnnotation(annotation)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationText.text = "failed with error \(error.localizedDescription) "
    }
    


    @IBAction func changeToggle(_ sender: UISwitch) {
        if toggleSwitch.isOn{
            if (CLLocationManager.locationServicesEnabled() == false) {
                self.toggleSwitch.isOn = false
            }
            
            if locationManager == nil {
                locationManager = CLLocationManager()
                locationManager.delegate = self
                locationManager.distanceFilter = 10.0
                locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
                locationManager.requestWhenInUseAuthorization()
            }
            locationManager.startUpdatingLocation()
        }
        else{
            if locationManager != nil {
                locationManager.stopUpdatingLocation()
            }
        }
    }

}

