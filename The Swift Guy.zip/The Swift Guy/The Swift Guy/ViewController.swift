//
//  ViewController.swift
//  The Swift Guy
//
//  Created by Augustine Akoto on 4/28/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var backgroundView: UIView!
   // var blurEffectView: UIVisualEffectView?

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.light)
//        
//        blurEffectView = UIVisualEffectView(effect: blurEffect)
//        
//        blurEffectView?.frame = view.bounds
//        
//        backgroundView.addSubview(blurEffectView!)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
//        
//        blurEffectView?.frame = view.bounds
//        
//    }
  

}

