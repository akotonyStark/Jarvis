//
//  GameOverViewController.swift
//  Swift Learner
//
//  Created by Augustine Akoto on 2/21/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit
import Parse

class GameOverViewController: UIViewController,UITextFieldDelegate {

  
    @IBOutlet var displayScore: FancyButton!
    @IBOutlet var submitScore: UIButton!
    @IBOutlet var returnHome: UIButton!
    @IBOutlet var usernameField: UITextField!
    
    var scoreData:String!
    
    
    @IBOutlet var backgroundView: UIView!
     var blurEffectView: UIVisualEffectView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         displayScore.setTitle(scoreData, for: .normal)
        
                let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.light)
        
                blurEffectView = UIVisualEffectView(effect: blurEffect)
        
                blurEffectView?.frame = view.bounds
        
                backgroundView.addSubview(blurEffectView!)
        
         self.usernameField.delegate = self
        // Do any additional setup after loading the view.
    
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event:
        
        UIEvent?) {
        
        self.view.endEditing(true)
        
    }
    
    
        override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
    
            blurEffectView?.frame = view.bounds
    
        }
    
    
    func textFieldShouldReturn(_ usernameField: UITextField) -> Bool {
        
        usernameField.resignFirstResponder()
        return true
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func resetToHome(_ sender: UIButton) {
        self.performSegue(withIdentifier: "gobackSegue", sender:sender)
    }
    
    @IBAction func submitScore(_ sender: FancyButton) {
        //now I need to send the data into the backEnd
        
        let data = PFObject(className: "Scoreboard")
        data["username"] = usernameField.text
        
//        let value: Int!
//        value = Int(scoreData)
        
        data["scores"] = scoreData
        
        data.saveInBackground { (successful, error) in
            if successful{
               print("successful")
            }
            else{
               print("not working")
            }
        }
        usernameField.text = ""
        

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if (segue.identifier == "gobackSegue")
//        {
//          self.performSegue(withIdentifier: "gobackSegue", sender: sender)
//        }
    }

   
  
}
