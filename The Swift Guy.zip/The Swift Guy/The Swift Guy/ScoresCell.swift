//
//  ScoresCell.swift
//  The Swift Guy
//
//  Created by Augustine Akoto on 4/28/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import Foundation
import UIKit
import Parse
import ParseUI

class ScoresCell: PFTableViewCell{
    
     @IBOutlet weak var usernameLabel: UILabel!
     @IBOutlet weak var scoreLabel: UIButton!
    
}
