//
//  GameViewController.swift
//  Swift Learner
//
//  Created by Augustine Akoto on 2/16/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit
import AVFoundation


class GameViewController: UIViewController {
    
    var backgroundMusic: AVAudioPlayer!
    var cSound: AVAudioPlayer!
    var wSound: AVAudioPlayer!
    
    var path = Bundle.main.path(forResource: "music.mp3", ofType:nil)!
    var cpath = Bundle.main.path(forResource: "correct.mp3", ofType:nil)!
    var wpath = Bundle.main.path(forResource: "wrong.mp3", ofType:nil)!
    
    var scores = 0
    var lifeline = 3
    var questionsCounter = 0
    var rightAnswerPlacement:UInt32 = 1

    

    @IBOutlet var optiononeButt: UIButton!
    @IBOutlet var optiontwoButt: UIButton!
    @IBOutlet var optionthreeButt: UIButton!
    @IBOutlet var optionfourButt: UIButton!
    @IBOutlet weak var questionNumberButt: UIButton!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet var life_one: UIButton!
    @IBOutlet var life_two: UIButton!
    @IBOutlet var life_three: UIButton!
    @IBOutlet var questionNumLabel: UILabel!

    
    @IBAction func stopMusic(_ sender: UIButton)
    {
        if(backgroundMusic != nil){
        pauseBackgroundMusic()
        }
        else if backgroundMusic==nil{
            backgroundMusic.play()
        }
    }
    
    
    //gamelogic
    @IBOutlet var questionsLabel: UITextView!
    
    let questions = [ "Swift programming language was designed as an update to which of the following programming languages?",
                      
                      "Which of the following keywords is used to declare a constant in Swift?",
                      
                      "Select the odd one out of the following options.",
                      
                      "Swift programming was developed by a company called...",
                      
                      "The development tool needed for iOS application development in swift is called...",
                      
                      "One may need the following in order to begin iOS application development except...",
                      
                      "Swift framework stack is built on a solid base of Foundation and...",
                      
                      "What does ARC in Swift programming stand for?",
                      
                      "We declare a function in Swift using the keyword...",
                      
                      "When a class wants to refer to itself in Swift, it uses the keyword...",
                      
                      "One of the most important differences between structures and classes is that...",
                      
                      "All of these can adopt protocols, except one. Which one is it?"
    
                    ]
    
    let options = [["Objective C", "Java", "JavaScript", "C language"],
                   
                   ["let", "static",  "const", "var"],
                   
                   ["JFrame","ViewController","Constraints", "Playground"],
                   
                   ["Apple", "Sun Microsystems", "Microsoft", "Google"],
                   
                   ["XCode", "Netbeans", "Xamarin Code", "Eclipse"],
                   
                   ["Router", "Macbook", "Xcode", "Apple ID"],
                   
                   ["Cocoa","Java", "Beans","Dalvik"],
                   
                   ["Automatic Reference Counting", "Advanced Repressed Code", "Automatic Reprecated Code", "Advanced Reference Counting"],
                   
                   ["func", "function", "public", "method"],
                   
                   ["self", "me", "this", "enum"],
                   
                   ["structures are copied when passed around", "structures are abstract", "structures cannot support methods", "structures have no field variables"],
                   
                   ["Dictionary", "Enumerations", "Classes", "Structs"]
                   
                  ]

    
    
    override func viewDidAppear(_ animated: Bool)
    {
        generateQuestion()
    }
    
    @IBAction func submitAnswer(_ sender: UIButton) {
        if (sender.tag == Int(rightAnswerPlacement))
        {
            scores += 5
            scoreLabel.text = ("\(scores)")
            playCorrectSound()
        }
        else
        {
            playWrongSound()
            lifeline = lifeline - 1
            if(lifeline == 2)
            {
                life_one.isHidden = true
            }
            else if(lifeline == 1){
                life_one.isHidden = true
                life_two.isHidden = true
            }
            else{
                print("Game Over)")
                self.performSegue(withIdentifier: "scoreboardsegue", sender: sender)
                pauseBackgroundMusic()
            }
        }
        //if the end of questions is not reached
        if(questionsCounter != questions.count)
        {
            generateQuestion()
             questionNumLabel.text = ("\(questionsCounter)")
        }
        else if(questionsCounter == questions.count)
        {
            self.performSegue(withIdentifier: "scoreboardsegue", sender: sender)
            pauseBackgroundMusic()
        }
        else{
            //
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "scoreboardsegue")
        {
            let data = segue.destination as! GameOverViewController
            data.scoreData = scoreLabel.text
        }
    }
    
    
    var button:UIButton = UIButton()
    
    func generateQuestion(){
        
        questionsLabel.text = questions[questionsCounter]
        
        rightAnswerPlacement = arc4random_uniform(4)+1
        
        
        
        var x = 1
        
        for i in 1...4
        {
            button = view.viewWithTag(i) as! UIButton
            if(i == Int(rightAnswerPlacement))
            {
                button.contentEdgeInsets = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 0)
                button.setTitle(options[questionsCounter][0], for: .normal)
                
            }
            else
            {
                button.contentEdgeInsets = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 0)
                button.setTitle(options[questionsCounter][x], for: .normal)
                x = x+1
            }
            
        }
        questionsCounter += 1

    }
    
    
    func playbackgroundSound(){
        
            do {
                let url = URL(fileURLWithPath: path)
                let sound = try AVAudioPlayer(contentsOf: url)
                backgroundMusic = sound
                backgroundMusic.play()
            }
            catch {
                // couldn't load file :(
            }
    }
    
    
    func playCorrectSound(){
        
        do {
            let url = URL(fileURLWithPath: cpath)
            let sound = try AVAudioPlayer(contentsOf: url)
            cSound = sound
            cSound.play()
        }
        catch {
            // couldn't load file :(
        }
    }
    
    func playWrongSound(){
        
        do {
            let url = URL(fileURLWithPath: wpath)
            let sound = try AVAudioPlayer(contentsOf: url)
            wSound = sound
            wSound.play()
        }
        catch {
            // couldn't load file :(
        }
    }
    
    
    //function to stop music
    func pauseBackgroundMusic(){
        backgroundMusic.pause()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Game Arena"
        
        playbackgroundSound()
        
        optiononeButt.layer.cornerRadius = 3.0
        optiontwoButt.layer.cornerRadius = 3.0
        optionthreeButt.layer.cornerRadius = 3.0
        optionfourButt.layer.cornerRadius = 3.0
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
