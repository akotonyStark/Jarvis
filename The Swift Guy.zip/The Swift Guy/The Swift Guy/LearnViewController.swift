//
//  LearnViewController.swift
//  Swift Learner
//
//  Created by Augustine Akoto on 2/17/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit

class LearnViewController: UIViewController,UIWebViewDelegate {

    @IBOutlet weak var webViewDisplay: UIWebView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var myProgressView: UIProgressView!
    
    var myTimer = Timer()
    var theBool = Bool()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.navigationItem.title = "Learn Swift"
        let webUrl : NSURL = NSURL(string: "https://teamtreehouse.com/library/swift-3-basics")!
        let webRequest : NSURLRequest = NSURLRequest(url: webUrl as URL)
        webViewDisplay.loadRequest(webRequest as URLRequest)
       
    }
    
    func timerCallback(){
        if theBool {
            if myProgressView.progress >= 1 {
                myProgressView.isHidden = true
                myTimer.invalidate()
            }else{
                myProgressView.progress += 0.1
            }
        }else{
            myProgressView.progress += 0.05
            if myProgressView.progress >= 0.95 {
                myProgressView.progress = 0.95
            }
        }
    }
    

    func webViewDidStartLoad(_ webView: UIWebView) {
        activityIndicator.startAnimating()
        myProgressView.progress = 0
        theBool = false
        myTimer =  Timer.scheduledTimer(timeInterval: 0.01667,target: self,selector: #selector(LearnViewController.timerCallback),userInfo: nil,repeats: true)
    }
    func webViewDidFinishLoad(_ webView: UIWebView) {
        activityIndicator.stopAnimating()
        theBool = true
    }

 
}
