//
//  ViewController.swift
//  Calculator 2.0
//
//  Created by Tony Stark on 2/8/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var clearButt: UIButton!
    @IBOutlet weak var delButt: UIButton!
    @IBOutlet weak var sinButt: UIButton!
    @IBOutlet weak var cosButt: UIButton!
    @IBOutlet weak var tanButt: UIButton!
    @IBOutlet weak var piButt: UIButton!
    @IBOutlet weak var numSeven: UIButton!
    @IBOutlet weak var numEight: UIButton!
    @IBOutlet weak var numNine: UIButton!
    @IBOutlet weak var numFour: UIButton!
    @IBOutlet weak var numFive: UIButton!
    @IBOutlet weak var numSix: UIButton!
    @IBOutlet weak var numOne: UIButton!
    @IBOutlet weak var numTwo: UIButton!
    @IBOutlet weak var numThree: UIButton!
    @IBOutlet weak var numZero: UIButton!
    
    @IBOutlet weak var sqrtButt: UIButton!
    @IBOutlet weak var equalButt: UIButton!
    @IBOutlet weak var divButt: UIButton!
    
    @IBOutlet weak var multiplyButt: UIButton!
    @IBOutlet weak var minusButt: UIButton!
    @IBOutlet weak var addButt: UIButton!
    @IBOutlet weak var display: UILabel!
    
    
    
    var currNum:Float = 0.0
    var currOperation = "="
    var result = Float()
    var pi = Double()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func buttonInput(_ sender: UIButton) {
        currNum = currNum * 10 + Float(Int(sender.currentTitle!)!)
        print(currNum)
        
        display.text = ("\(currNum)")
    }
  
    @IBAction func clearAction(_ sender: UIButton) {
        currNum = 0;
        currOperation = "="
        result = 0;
        display.text = ("\(result)")
    }
    
    @IBAction func backspace(_ sender: UIButton) {
        let newResults = display.text!
        display.text  = String(newResults.characters.dropLast())
    }

    @IBAction func operationButtonAction(_ sender: UIButton) {
        switch currOperation{
            
        case "=" :
            result = currNum
        case "+" :
            result += currNum
        case "-" :
            result -= currNum
        case "*" :
            result *= currNum
        case "÷" :
            result /= currNum
        default:
            print("error")
            
        }
        
        currNum = 0;
        display.text = ("\(result)")
        
        
        if(sender.titleLabel!.text == "="){
            result = 0;
        }
        
        currOperation = sender.titleLabel!.text! as String!
        //         results.text = currOperation
    }
    
    
    @IBAction func sinAction(_ sender: UIButton) {
        let getData =  (display.text! as NSString).doubleValue
        print(("\(getData)"))
        let sine = sin(getData)
        display.text = ("\(sine)")
    }
    
    @IBAction func cosAction(_ sender: UIButton) {
        let getData =  (display.text! as NSString).doubleValue
        print(("\(getData)"))
        let cosine = cos(getData)
        display.text = ("\(cosine)")
    }
    
    @IBAction func tanAction(_ sender: UIButton) {
        let getData =  (display.text! as NSString).doubleValue
        print(("\(getData)"))
        let tangent = tan(getData)
        display.text = ("\(tangent)")
    }
    
    @IBAction func piAction(_ sender: UIButton) {
        let getData =  (display.text! as NSString).doubleValue
        
        if(display.text == "0" || display.text == "0.0"){
            let pi = M_PI
            display.text = ("\(pi)")
        }
            
        else{
            let pi = M_PI * getData
            display.text = ("\(pi)")
        }
        
           }
    
    
    @IBAction func sqaureRoot(_ sender: UIButton) {
        let getData =  (display.text! as NSString).doubleValue
        let root = sqrt(getData)
        display.text = ("\(root)")
    }

    
    
    
    
    
    
}

