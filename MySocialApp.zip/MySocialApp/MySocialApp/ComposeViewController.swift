//
//  ViewController.swift
//  MySocialApp
//
//  Created by Tony Stark on 3/5/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit

class ComposeViewController: UIViewController {

    @IBOutlet var tweetContent: UITextView!
    @IBOutlet var postButton: UIButton!
    @IBOutlet var postActivity: UIActivityIndicatorView!
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

  
    @IBAction func postToTwitter(_ sender: UIButton) {
        
    }
    
    
    @IBAction func dismissView(_ sender: UIButton) {
          self.dismiss(animated: true, completion: nil)
    }

}

