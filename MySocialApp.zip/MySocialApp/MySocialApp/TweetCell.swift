//
//  TweetCell.swift
//  MySocialApp
//
//  Created by Tony Stark on 3/7/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit

class TweetCell: UITableViewCell {
    
    @IBOutlet var tweetUserAvatar: UIImageView!
    @IBOutlet var tweetUsername: UILabel!
    @IBOutlet var tweetContent: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
