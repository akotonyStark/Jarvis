
//  Leaderboard.swift
//  Dont Drop It
//
//  Created by Augustine Akoto on 4/29/17.
//  Copyright © 2017 Augustine Akoto Larbi-Ampofo. All rights reserved.
//

import UIKit
import Parse
import ParseUI

class Leaderboard: PFQueryTableViewController {
    
    override func queryForTable() -> PFQuery<PFObject> {
        let query = PFQuery(className: "Scoreboard" )
        query.order(byDescending: "scores")
        return query
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func tableView(_ tableView:UITableView, cellForRowAt indexPath: IndexPath, object: PFObject?) -> PFTableViewCell?{
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ScoresCell
        
        cell.usernameLabel.text = object?.object(forKey: "username") as? String
        
        let scoreValue  = object?.object(forKey: "scores") as? String
        
        cell.scoreLabel.setTitle(scoreValue, for: .normal)
        
        return cell
    }
    
    //
    //    override func numberOfSections(in tableView: UITableView) -> Int {
    //        // #warning Incomplete implementation, return the number of sections
    //        return 1
    //    }
    
    
}
